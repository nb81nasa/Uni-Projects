function showFailTable() { parent.leftnav.showFailTable(); }
