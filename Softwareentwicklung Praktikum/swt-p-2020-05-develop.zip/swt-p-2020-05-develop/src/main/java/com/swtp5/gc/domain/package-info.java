/**
 * JPA domain objects.
 */
package com.swtp5.gc.domain;
