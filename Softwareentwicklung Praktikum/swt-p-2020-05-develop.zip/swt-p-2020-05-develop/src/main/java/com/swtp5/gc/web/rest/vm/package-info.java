/**
 * View Models used by Spring MVC REST controllers.
 */
package com.swtp5.gc.web.rest.vm;
