/**
 * Data Transfer Objects.
 */
package com.swtp5.gc.service.dto;
