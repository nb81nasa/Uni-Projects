/**
 * Spring Data JPA repositories.
 */
package com.swtp5.gc.repository;
