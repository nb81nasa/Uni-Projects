/**
 * Spring Framework configuration files.
 */
package com.swtp5.gc.config;
