/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.swtp5.gc.service.mapper;
