/**
 * Spring Security configuration.
 */
package com.swtp5.gc.security;
