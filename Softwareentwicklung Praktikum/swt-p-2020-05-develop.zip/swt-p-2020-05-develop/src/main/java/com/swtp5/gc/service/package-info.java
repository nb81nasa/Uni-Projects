/**
 * Service layer beans.
 */
package com.swtp5.gc.service;
