# Geplante Projektarchitektur 
![Architektur](/uploads/81a732d54f80b7a0496b9954f8da191c/Architektur.png)


## Branches 🌿

- **Master-Branch:** funktionierender Vue.js Prototyp
- **Develop-Branch:** komplette Programmarchitektur in einem von JHipster erstellten Basisprojekt als Grundbaustein für die weitere Entwicklung


## Rollenaufteilung 📜 
| | |
|-|-|
|Teamleiter|Leander  
|Dev|Johanna  
|Dev|Maximus  
|GUI|Daniel  
|GUI|Nodira
|DevOps|Dolph    
|Tester|Jonathan  


