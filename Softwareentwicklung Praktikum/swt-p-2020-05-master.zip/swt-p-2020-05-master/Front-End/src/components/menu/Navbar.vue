<template>
  <div>
    <v-app-bar color="green" dense app clipped-left>
      <v-spacer></v-spacer>
      <router-link to="/" class="v-toolbar__title">
        <v-toolbar-title class="white--text"
          >Green Configurator</v-toolbar-title
        >
      </router-link>
      <v-spacer></v-spacer>
      <v-btn icon @click="user = !user" v-if="user">
        <v-icon>mdi-account-circle</v-icon>
      </v-btn>
      <v-btn v-else @click="user = !user" color="warning">Login</v-btn>
    </v-app-bar>
    <Drawer
      v-if="
        $vuetify.breakpoint.md ||
          $vuetify.breakpoint.lg ||
          $vuetify.breakpoint.xl
      "
    />
  </div>
</template>

<script>
import Drawer from '@/components/menu/Drawer.vue';

export default {
  name: 'Navbar',
  components: {
    Drawer,
  },
  data() {
    return {
      user: false,
    };
  },
};
</script>

<style scoped>
a {
  text-decoration: none;
}
</style>
