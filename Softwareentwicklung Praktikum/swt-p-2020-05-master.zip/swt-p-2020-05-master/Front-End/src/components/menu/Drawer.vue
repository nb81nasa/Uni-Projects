<template>
  <v-navigation-drawer clipped permanent app fixed>
    <v-list nav>
      <template v-for="(item, index) in categories">
        <v-subheader v-if="item.header" :key="item.header" v-text="item.header">
        </v-subheader>
        <v-divider v-else-if="item.divider" :key="index"></v-divider>
        <v-list-item v-else :key="item.category" :to="item.link"
          ><v-list-item-content
            ><v-list-item-title
              v-text="item.category"
            ></v-list-item-title></v-list-item-content
        ></v-list-item>
      </template>
    </v-list>
  </v-navigation-drawer>
</template>

<script>
export default {
  name: 'Drawer',
  data() {
    return {
      categories: [
        { header: 'Aktionen' },
        { divider: true },
        { category: 'Konfiguration auswerten', link: '/' },
        { divider: true },
        { category: 'Konfigurationen vergleichen', link: '/vergleich' },
      ],
    };
  },
};
</script>
