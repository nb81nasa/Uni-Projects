<template>
    <v-card class="ma-2">
        <v-card-title>Konfigurationen vergleichen</v-card-title>
        <v-card-text>
            <v-container>
                <v-row>
                    <v-select :items="['Apache', 'MySQL-Database']"
                    label="Program" color="orange"></v-select>
                </v-row>
                <v-row>
                    <v-col cols="6">
                        <v-file-input label="1. Datei" color="orange"></v-file-input>
                    </v-col>
                    <v-col cols="6">
                        <v-file-input label="2. Datei" color="orange"></v-file-input>
                    </v-col>
                </v-row>
                <v-row>
                    <v-spacer></v-spacer>
                    <v-btn color="orange" class="mr-3 white--text">Vergleichen</v-btn>
                </v-row>
            </v-container>
        </v-card-text>
    </v-card>
</template>

<script>

export default {
  name: 'Comparison',
};
</script>
