<template>
    <v-card class="ma-2">
        <v-card-title>Konfiguration auswerten</v-card-title>
        <v-card-text>
            <v-container>
                <v-row>
                    <v-select :items="['Apache', 'MySQL-Database', 'Neues Program beantragen']"
                    label="Program" color="orange" v-model="programm"></v-select>
                </v-row>
                <v-row v-if="programm == 'Neues Program beantragen'">
                    <v-col v-bind:cols="toArrays *2 ">
                        <v-text-field label="Programname" color="orange"></v-text-field>
                    </v-col>
                </v-row>
                <v-row v-else> <!--TODO col fixen -->
                  <v-col v-bind:cols="toArrays.length" class="ml-3">

                        <v-switch v-bind:key="toArray.id" v-for="toArray in toArrays"
                            v-bind:label="toArray.name"
                                  color="orange"
                                  type="switch" id="switch" v-model="toArray.use"
                        />

                  </v-col>

                  <v-col v-bind:cols="toArrays2.length">

                      <v-switch v-bind:key="toArray2.id" v-for="toArray2 in toArrays2"
                          v-bind:label="toArray2.name"
                                color="orange"
                                type="switch" id="switch" v-model="toArray2.use"
                      />
                    </v-col>
                </v-row>
                <v-row>
                    <v-spacer></v-spacer>
                    <v-btn color="orange" class="white--text">
                        {{ programm == 'Neues Program beantragen' ? 'Beantragen' : 'Auswerten' }}
                    </v-btn>
                </v-row>
            </v-container>
        </v-card-text>
    </v-card>
</template>

<script>

export default {
  name: 'Configurator',
  data() {
    return {
      programm: 'Apache',
      //rawdata ist die ausgelesen Dimacs als String schon geteilt
      rawdata:"c 1 root c 2 compressed_script c 3 encryption c 4 crypt_aes"
          +"c 5 crypt_blowfish"+
          "c 6 transaction_control"+
          "c 7 txc_mvlocks"+
          "c 8 txc_mvcc"+
          "c 9 txc_locks"+
          "c 10 table_type"+
          "c 11 memory_tables" +
          "c 12 cached_tables"+
          "c 13 small_cache"+
          "c 14 large_cache"+
          "c 15 logging"+
          "c 16 detailed_logging"+
          "c 17 no_write_delay"+
          "c 18 small_log"+
          "p cnf 18 17",
    };
  },
  computed: {
    // bring die raw data in ein Array von configurationen
    // toArray bringt die erste Hälfte der Confius als Array über die Klasse Cof zurück
    //toArtay2 bringt die Hälfte der Confis zurück
    toArrays: function () {

      class Cof {
        constructor(name, use,grey) {
          this.name = name;
          this.use = use;
          this.grey = grey; //notwendiges Feature
        }
      }

      var str = this.rawdata.split('c ') ;
      let confiList1 = []

      for(var i = 0;i < (str.length -1)/2 ;i++){

          confiList1[i] = new Cof(str[i + 1], false, true)

      }
      confiList1[3].grey = false;// dummy-Objekt zur Probe
      return confiList1
    },
    toArrays2: function () {

      class Cof {
        constructor(name, use,grey) {
          this.name = name;
          this.use = use;
          this.grey = grey; //notwendiges Feature
        }
      }

      var str = this.rawdata.split('c ') ;
      let confiList1 = []

      for(var i = (str.length -1)/2;i < (str.length -1);i++){

        confiList1[i-(str.length -1)/2] = new Cof(str[i + 1], false, true)

      }

      return confiList1
    }
  },




};
</script>
